package com.project.Inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.project.Inventory.model.Seller;
import com.project.Inventory.repository.Sellerrepo;


@Controller
public class SellerController 
{
	
	
	@Autowired
	public Sellerrepo selrepo;	
	@RequestMapping("/register")
	public String register()
	{
		return "RegSeller.jsp";
	}
	
	@RequestMapping("/Login")
	public String Login()
	{
		return "logSeller.jsp";
	}
	
	@GetMapping("/Sellerlog")
	public String Sellerlog(@RequestParam String email, @RequestParam String password)
	{
		System.out.println(email+" "+password);
		Seller o=selrepo.findByEmail(email);
		if(o!=null && o.getEmail().equalsIgnoreCase(email) && o.getPassword().equals(password))
		{
			return "WelcomeSeller.jsp";
		}
		else
		{
			return "logSeller.jsp";
		}
	}
	
	@PostMapping("/SelReg")
	public String SelReg(@ModelAttribute Seller s)
	{
		System.out.println(s);
		selrepo.save(s);
		return "logSeller.jsp";
	}
	
	@RequestMapping("/datafetchSeller")
	public String datafetchSeller(Model m)
	{
		List<Seller> seller_data = selrepo.findAll();
		System.out.println(seller_data);
		m.addAttribute("data1", seller_data);
		return "Sellerdatafetch.jsp";
	}
	
	@GetMapping("/id/{id}")
	public String editseller(@PathVariable int id, Model m)
	{
		Seller a1=selrepo.findById(id).orElse(null);
		m.addAttribute("edit1", a1);
		return "editSel.jsp";
	}
	@PostMapping("/editsel/{id}")
	public String updateSeller(@PathVariable int id,@ModelAttribute Seller ob1)
	{
		Seller sel1=selrepo.findById(id).orElse(null);
		if(sel1 != null)
		{
			sel1.setFirst_name(ob1.getFirst_name());
			sel1.setLast_name(ob1.getLast_name());
			sel1.setEmail(ob1.getEmail());
			sel1.setPhone(ob1.getPhone());
			sel1.setCity(ob1.getCity());
			sel1.setPincode(ob1.getPincode());
			sel1.setAddress(ob1.getAddress());
			sel1.setPassword(ob1.getPassword());
		}
		selrepo.save(sel1);
		return "redirect:/datafetchSeller";
	}
	
	@RequestMapping("/deletesel/{id}")
	public String deletesel(@PathVariable int id)
	{
			selrepo.deleteById(id);
		return "redirect:/datafetchSeller";
	}	
}
