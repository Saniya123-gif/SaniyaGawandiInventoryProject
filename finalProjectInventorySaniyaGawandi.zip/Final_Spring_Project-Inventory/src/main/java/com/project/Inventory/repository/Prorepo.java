package com.project.Inventory.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.Inventory.model.Product;

@Repository
public interface Prorepo extends JpaRepository<Product, Integer>
{

}
