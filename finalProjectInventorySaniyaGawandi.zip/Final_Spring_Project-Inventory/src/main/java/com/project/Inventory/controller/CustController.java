package com.project.Inventory.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.Inventory.model.Customer;
import com.project.Inventory.repository.Custrepo;
@Controller
public class CustController
{
	@Autowired
	public Custrepo curepo;

	@GetMapping("/")
	public String mainpage()
	{
		return "mainPage.jsp";
	}
	@RequestMapping("/Register")
	public String reg()
	{
		return "RegCustomer.jsp";
	}
	@RequestMapping("/login")
	public String login()
	{
		return "loginCust.jsp";
	}
	
	@PostMapping("/CustReg")
	public String reg(@ModelAttribute Customer c)
	{
		System.out.println(c);
		curepo.save(c);
		return "loginCust.jsp";
	}
	
	@GetMapping("/Custlog")
	public String log(@RequestParam String email, @RequestParam String password)
	{
		System.out.println(email+" "+password);
		Customer o=curepo.findByEmail(email);
		if(o!=null && o.getEmail().equalsIgnoreCase(email) && o.getPassword().equals(password))
		{
			return "WelcomeCust.jsp";
		}
		else
		{
			return "loginCust.jsp";
		}
	}
	
	@RequestMapping("/datafetchCust")
	public String fetch(Model m)
	{
		List<Customer> cust_data = curepo.findAll();
		System.out.println(cust_data);
		m.addAttribute("data", cust_data);
		return "Custdatafetch.jsp";
	}
	
	@GetMapping("/{id}")
	public String edit(@PathVariable int id, Model m)
	{
		Customer ob=curepo.findById(id).orElse(null);
		m.addAttribute("edit_data", ob);
		return "editCust.jsp";
	}
	@PostMapping("/edit/{id}")
	public String update(@PathVariable int id,@ModelAttribute Customer ob)
	{
		Customer cus1=curepo.findById(id).orElse(null);
		if(cus1 != null)
		{
			cus1.setFirst_name(ob.getFirst_name());
			cus1.setLast_name(ob.getLast_name());
			cus1.setEmail(ob.getEmail());
			cus1.setPhone(ob.getPhone());
			cus1.setCity(ob.getCity());
			cus1.setPincode(ob.getPincode());
			cus1.setAddress(ob.getAddress());
			cus1.setPassword(ob.getPassword());
		}
		curepo.save(cus1);
		return "redirect:/datafetchCust";
	}
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id)
	{
			curepo.deleteById(id);
		return "redirect:/datafetchCust";
	}	
	
	
}
