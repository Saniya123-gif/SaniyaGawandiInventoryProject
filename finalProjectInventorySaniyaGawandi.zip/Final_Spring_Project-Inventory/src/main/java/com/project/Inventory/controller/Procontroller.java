package com.project.Inventory.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.project.Inventory.model.Product;
import com.project.Inventory.repository.Prorepo;

@Controller
public class Procontroller 
{
	@Autowired
	public Prorepo prepo;
	
	@PostMapping("/addPro")
	public String addPro(@ModelAttribute Product p)
	{
		System.out.println(p);
		prepo.save(p);
		return "welcomPro.jsp";
	}
	
	@RequestMapping("/datafetchPro")
	public String datafetchPro(Model m)
	{
		List<Product> Pro_data = prepo.findAll();
		System.out.println(Pro_data);
		m.addAttribute("dataPro", Pro_data);
		return "viewPro.jsp";
	}
	
	@RequestMapping("/deletepro/{product_id}")
	public String deletePro(@PathVariable int product_id)
	{
			prepo.deleteById(product_id);
		return "redirect:/datafetchPro";
	}	
	
	@GetMapping("pro_id/{product_id}")
	public String editPro( Model m5,@PathVariable int product_id)
	{
		Product pro2=prepo.findById(product_id).orElse(null);
		m5.addAttribute("edit_Pro", pro2);
		return "editPro.jsp";
	}
	
	@PostMapping("/EditPro/{product_id}")
	public String updatePro(@PathVariable int product_id,@ModelAttribute Product pro3)
	{
		Product pro1=prepo.findById(product_id).orElse(null);
		if(pro1 != null)
		{
			pro1.setProduct_title(pro3.getProduct_title());
			pro1.setProduct_brand(pro3.getProduct_brand());
			pro1.setProduct_description(pro3.getProduct_description());
			pro1.setCategory(pro3.getCategory());
			pro1.setProduct_Stock(pro3.getProduct_Stock());
			pro1.setProduct_prize(pro3.getProduct_prize());
			pro1.setProduct_status(pro3.getProduct_status());
		}
		prepo.save(pro1);
		return "redirect:/datafetchPro";
	}
	
	
	@RequestMapping("/addtocart")
	public String addtocart( Model m7) 
	{
		List<Product> Pro_data3 = prepo.findAll();
		System.out.println(Pro_data3);
		m7.addAttribute("addToCart", Pro_data3);
	    return "myJs.jsp";  
	}

	
}
