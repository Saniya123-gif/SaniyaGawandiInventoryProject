package com.project.Inventory.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class Product 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int product_id;
	private String product_title;
	private String product_brand;
	private String product_description;
	private String Category;
	private int product_Stock;
	private int product_prize;
	private String product_status;
	
	public Product(int product_id, String product_title, String product_brand, String product_description,
			String category, int product_Stock, int product_prize, String product_status) {
		super();
		this.product_id = product_id;
		this.product_title = product_title;
		this.product_brand = product_brand;
		this.product_description = product_description;
		Category = category;
		this.product_Stock = product_Stock;
		this.product_prize = product_prize;
		this.product_status = product_status;
		
	}
	public int getProduct_Stock() {
		return product_Stock;
	}
	public void setProduct_Stock(int product_Stock) {
		this.product_Stock = product_Stock;
	}
	public int getProduct_prize() {
		return product_prize;
	}
	public void setProduct_prize(int product_prize) {
		this.product_prize = product_prize;
	}
	public String getProduct_status() {
		return product_status;
	}
	public void setProduct_status(String product_status) {
		this.product_status = product_status;
	}
	
	public String getProduct_brand() {
		return product_brand;
	}
	public void setProduct_brand(String product_brand) {
		this.product_brand = product_brand;
	}
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_title=" + product_title + ", product_brand="
				+ product_brand + ", product_description=" + product_description + ", Category=" + Category
				+ ", product_Stock=" + product_Stock + ", product_prize=" + product_prize + ", product_status="
				+ product_status + "]";
	}
	public String getProduct_title() 
	{
		return product_title;
	}
	public void setProduct_title(String product_title) 
	{
		this.product_title = product_title;
	}
	public String getProduct_description() 
	{
		return product_description;
	}
	public void setProduct_description(String product_description)
	{
		this.product_description = product_description;
	}
	public String getCategory()
	{
		return Category;
	}
	public void setCategory(String category) 
	{
		Category = category;
	}
	
	public int getProduct_id()
	{
		return product_id;
	}
	public void setProduct_id(int product_id)
	{
		this.product_id = product_id;
	}

	public Product() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

}
