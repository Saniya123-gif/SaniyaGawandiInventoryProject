package com.project.Inventory.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.project.Inventory.model.Customer;

@Repository
public interface Custrepo extends JpaRepository<Customer, Integer> 
{
	public Customer findByEmail(String email);
}